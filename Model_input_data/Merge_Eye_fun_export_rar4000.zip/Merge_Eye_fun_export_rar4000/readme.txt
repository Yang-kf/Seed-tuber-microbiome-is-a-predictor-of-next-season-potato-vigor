HeelEye2019.26.12.E.ITS_000000000.JKP74
HeelEye2019.26.34.E.ITS_000000000.JLBMN

These 2 samples are in Merge_Eye_fun_all_feature-table_rar4000_HFE.tsv but not in Merge_Eye_fun_all_label_vector_HFE
Were removed from Merge_Eye_fun_all_feature-table_rar4000_HFE.tsv